# To Do

 - Factor `Abstract_game` into `Abstract_view` and `Abstract_controller`.

 - Make int versions of geometry structs friendlier.

 - [Fix your timestep!](https://gafferongames.com/post/fix_your_timestep/)

